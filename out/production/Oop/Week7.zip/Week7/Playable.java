package Week7;

public interface Playable {
  public void play();
}
