package Week7;

public class DigitalVideoDisc extends Discs {
	public DigitalVideoDisc() {
	}

	public void getDetail(){
		super.getDetail();
	}

  public void play() {

  }
}